import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Activity, Server, Database, Box, Cpu, HardDrive, RefreshCw } from 'lucide-react';

const App = () => {
    const [data, setData] = useState(null);
    const [loading, setLoading] = useState(true);
    const [lastUpdated, setLastUpdated] = useState(new Date());

    const fetchData = async () => {
        try {
            const res = await fetch(`http://${window.location.hostname}:3001/api/stats`);
            const json = await res.json();
            setData(json);
            setLastUpdated(new Date());
            setLoading(false);
        } catch (err) {
            console.error('Failed to fetch stats', err);
        }
    };

    useEffect(() => {
        fetchData();
        const interval = setInterval(fetchData, 3000);
        return () => clearInterval(interval);
    }, []);

    const fadeInUp = {
        hidden: { opacity: 0, y: 20 },
        visible: { opacity: 1, y: 0, transition: { duration: 0.5, ease: "easeOut" } }
    };

    if (loading) {
        return (
            <div style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', height: '100vh', width: '100%' }}>
                <motion.div animate={{ rotate: 360 }} transition={{ repeat: Infinity, duration: 1 }}>
                    <RefreshCw size={48} color="#3b82f6" />
                </motion.div>
            </div>
        );
    }

    return (
        <div style={{ padding: '40px', maxWidth: '1400px', margin: '0 auto', width: '100%' }}>
            <header style={{ marginBottom: '40px', display: 'flex', justifyContent: 'space-between', alignItems: 'flex-end' }}>
                <div>
                    <motion.h1 initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>Kynto Server</motion.h1>
                    <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} style={{ color: '#a1a1aa' }}>
                        {data.system.os.hostname} • {data.system.os.distro} {data.system.os.release}
                    </motion.p>
                </div>
                <div style={{ textAlign: 'right', fontSize: '14px', color: '#71717a' }}>
                    Last updated: {lastUpdated.toLocaleTimeString()}
                </div>
            </header>

            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(300px, 1fr))', gap: '24px', marginBottom: '48px' }}>
                <motion.div className="glass-card" variants={fadeInUp} initial="hidden" animate="visible">
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
                        <Cpu size={20} color="#3b82f6" />
                        <h3 style={{ margin: 0 }}>CPU Load</h3>
                    </div>
                    <div style={{ fontSize: '32px', fontWeight: 'bold' }}>{Math.round(data.system.cpu.load)}%</div>
                    <div style={{ color: '#a1a1aa', fontSize: '14px' }}>{data.system.cpu.brand}</div>
                    <div className="progress-bar">
                        <div className="progress-fill" style={{ width: `${data.system.cpu.load}%` }}></div>
                    </div>
                </motion.div>

                <motion.div className="glass-card" variants={fadeInUp} initial="hidden" animate="visible" transition={{ delay: 0.1 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
                        <Server size={20} color="#10b981" />
                        <h3 style={{ margin: 0 }}>Memory</h3>
                    </div>
                    <div style={{ fontSize: '32px', fontWeight: 'bold' }}>
                        {Math.round(data.system.memory.used / 1024 / 1024 / 1024 * 10) / 10} GB
                        <span style={{ fontSize: '16px', color: '#71717a', marginLeft: '8px' }}>
                            / {Math.round(data.system.memory.total / 1024 / 1024 / 1024)} GB
                        </span>
                    </div>
                    <div className="progress-bar">
                        <div className="progress-fill" style={{ width: `${(data.system.memory.used / data.system.memory.total) * 100}%`, background: '#10b981' }}></div>
                    </div>
                </motion.div>

                <motion.div className="glass-card" variants={fadeInUp} initial="hidden" animate="visible" transition={{ delay: 0.2 }}>
                    <div style={{ display: 'flex', alignItems: 'center', gap: '12px', marginBottom: '16px' }}>
                        <HardDrive size={20} color="#f59e0b" />
                        <h3 style={{ margin: 0 }}>Disk Usage</h3>
                    </div>
                    {data.system.disk.slice(0, 1).map((d, i) => (
                        <div key={i}>
                            <div style={{ fontSize: '32px', fontWeight: 'bold' }}>{Math.round(d.use)}%</div>
                            <div style={{ color: '#a1a1aa', fontSize: '14px' }}>{d.mount} ({Math.round(d.used / 1024 / 1024 / 1024)} GB used)</div>
                            <div className="progress-bar">
                                <div className="progress-fill" style={{ width: `${d.use}%`, background: '#f59e0b' }}></div>
                            </div>
                        </div>
                    ))}
                </motion.div>
            </div>

            <h2 style={{ marginBottom: '24px' }}>Docker Containers</h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fit, minmax(400px, 1fr))', gap: '20px' }}>
                <AnimatePresence>
                    {data.docker.map((container, idx) => (
                        <motion.div
                            key={container.id}
                            className="glass-card"
                            initial={{ opacity: 0, scale: 0.9 }}
                            animate={{ opacity: 1, scale: 1 }}
                            transition={{ delay: idx * 0.05 }}
                            whileHover={{ y: -5, borderColor: 'rgba(255,255,255,0.2)' }}
                        >
                            <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'flex-start' }}>
                                <div>
                                    <div style={{ display: 'flex', alignItems: 'center' }}>
                                        <div className={`status-dot ${container.state === 'running' ? 'status-running' : 'status-stopped'}`}></div>
                                        <h4 style={{ margin: 0 }}>{container.name}</h4>
                                    </div>
                                    <div style={{ color: '#71717a', fontSize: '12px', marginTop: '4px' }}>{container.image}</div>
                                </div>
                                <div style={{ fontSize: '12px', padding: '4px 8px', background: 'rgba(255,255,255,0.05)', borderRadius: '4px', textTransform: 'uppercase' }}>
                                    {container.status}
                                </div>
                            </div>
                        </motion.div>
                    ))}
                </AnimatePresence>
            </div>
        </div>
    );
};

export default App;
